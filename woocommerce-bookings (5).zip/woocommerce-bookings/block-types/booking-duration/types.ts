export interface Attributes {
	textAlign: string;
	prefix: string;
	suffix: string;
}
