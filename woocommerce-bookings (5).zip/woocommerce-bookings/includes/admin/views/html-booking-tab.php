<?php
/**
 * Admin View: Booking Tab
 *
 * @package WooCommerce Bookings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<li class="bookings_tab bookings_resources_tab advanced_options show_if_booking"><a href="#bookings_resources"><?php esc_html_e( 'Resources', 'woocommerce-bookings' ); ?></a></li>
<li class="bookings_tab bookings_availability_tab advanced_options show_if_booking"><a href="#bookings_availability"><?php esc_html_e( 'Availability', 'woocommerce-bookings' ); ?></a></li>
<li class="bookings_tab bookings_pricing_tab advanced_options show_if_booking"><a href="#bookings_pricing"><?php esc_html_e( 'Costs', 'woocommerce-bookings' ); ?></a></li>
<li class="bookings_tab bookings_persons_tab advanced_options show_if_booking"><a href="#bookings_persons"><?php esc_html_e( 'Persons', 'woocommerce-bookings' ); ?></a></li>
